import { name } from "./export.js";
import myage from "./export.js";
import number from "./export.js";
console.log(name);
console.log(myage); 

console.log(number);  
