export const name = 'john doe';
 const age = 20;
 export default age;
//  export default name; // error