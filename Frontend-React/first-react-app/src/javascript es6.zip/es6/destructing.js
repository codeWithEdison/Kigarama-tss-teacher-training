
// array destruction

let numbers =[1,2,3,4,5,6,7,8,9,10];
// let one = numbers[0];
// let two = numbers[1];
let [a, two, three,,,,,,,ten] = numbers;
// console.log(seven);

let vehicle = {
    brand: "Toyota",
    model: "Camry",
    year: 2020
}
// let brand = vehicle.brand;
// let model = vehicle.model;
let {brand, model,year} = vehicle;


