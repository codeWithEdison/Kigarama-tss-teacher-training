
// without arrow
function hello(){
    return 'hello my friends';
}
// with arrow
const hello1 =()=>'hello';

function add(a,b){
    return a+b;
}
// with arrow
let add1 =(a,b)=>a+b;