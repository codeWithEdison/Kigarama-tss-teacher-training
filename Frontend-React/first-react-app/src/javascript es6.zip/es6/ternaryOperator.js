
//  ? : 
let age = 20;

let isAdults;
// if(age > 18){
//     isAdults = true;
// } else {
//     isAdults = false;
// }
//with ternary operator
isAdults = (age>18) ? true : false ;
console.log(isAdults); 

