// es5
var myname = 'edison';
// pi = 100;
// console.log(pi);  // accessing block variable


{
    const pi = 3.14;
    let a = 300;
    console.log(myname);
    var age = 20
    
    
    
}

// console.log(a);
console.log(age); 